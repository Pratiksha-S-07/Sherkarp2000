package com.bo;

public class Emp {
	private int id;
	private String name;
	private String email;
	private String phn;
	private String Password;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		this.Password = password;
	}
	
	public Emp( String name, String email, String phn, String password) {
		super();
		
		this.name = name;
		this.email = email;
		this.phn = phn;
		this.Password = password;
	}
	
	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Emp [ name=" + name + ", email=" + email + ", phn=" + phn + ", password=" + Password
				+ "]";
	}
	
	

}
